package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class MainProject {
    public static void main(String args[]) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select the appropriate number based on your choice");
        System.out.println("1. Open Browser");
        System.out.println("2. Open Given URL");
        System.out.println("3. Open Browser with Credentials");
        System.out.println("4. Open URL with Credentials and Response on Invalid Credentials");
        System.out.println("5. Implement All Locators (Static)");
        System.out.println("6. Implement CSS Selector (Dynamic)");
        System.out.println("7. Implement XPath (Dynamic)");
        System.out.println("8. Implement Single Dropdown");
        System.out.println("9. Implement Multiple Dropdown");
        System.out.println("10. Checkbox Implementation");
        System.out.println("11. Radio Button Implementation");
        System.out.println("12. Simple Alert");
        System.out.println("13. Confirm Alert");
        System.out.println("14. Prompt Alert");
        System.out.println("15. Take Screenshot after GitHub Login");
        System.out.println("Please select one number from the above to view to alert message from the browser");

        int select = scanner.nextInt();

        switch (select) {

            case 1:
                simplealert();
                break;

            case 2:
                confirmalert();
                break;
            case 3:
                promptalert();
                break;
            case 4:
                openbrowser();
                break;
            case 5:
                openurl();
                break;
            case 6:
                takescreenshot();
                break;
            case 7:
                openurlwithcredentials();
                break;
            case 8:
                singledropdown();
                break;
            case 9:
                multipledropdown();
                break;
            case 10:
                checkbox();
                break;
            case 11:
                radiobutton();
                break;
            case 12:
                cssselector();
                break;
            case 13:
                xpath();
                break;
            case 14:
                openBrowserWithCredentials();
                break;
            case 15:
                allstaticlocators();
                break;

            default:
                System.out.println("This is not a case that you must select");
                break;

        }
    }
    private static void allstaticlocators()
    {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.selenium.dev");
        WebElement elementById = driver.findElement(By.id("someId"));
        WebElement elementByName = driver.findElement(By.name("someName"));
        WebElement elementByClassName = driver.findElement(By.className("someClass"));
        WebElement elementByTagName = driver.findElement(By.tagName("button"));
        WebElement elementByLinkText = driver.findElement(By.linkText("Downloads"));
        System.out.println("Locators Implemented Successfully.");
    }
    private static void openBrowserWithCredentials() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (username.equals("validUsername") && password.equals("validPassword")) {
            WebDriver driver;
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.get("https://www.example.com");
            System.out.println("Browser opened successfully with valid credentials!");
        } else {
            System.out.println("Invalid credentials. Browser will not open.");
        }
    }
    private static void openurlwithcredentials() {
        WebDriver driver9;
        WebElement element;
        WebDriverManager.chromedriver().setup();
        driver9=new ChromeDriver();
        driver9.get("https://github.com/login");
        System.out.println("Working with Locators");
        driver9.findElement(By.cssSelector("#login_field")).sendKeys("2200030823@kluniversity.in");
        highlight9(driver9,driver9.findElement(By.cssSelector("#login_field")));
        driver9.findElement(By.cssSelector("#password")).sendKeys("Sowjanya@1980");
    }
    private static void xpath()
    {
        System.setProperty("webdriver.chrome.driver", "Your-Chrome-Driver-Path");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("https://login.yahoo.com/account/create");
        driver.findElement(By.xpath("//input[@id='usernamereg-firstName']")).sendKeys("Your-Name");
    }

    private static void cssselector()
    {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.gmail.com");
        driver.findElement(By.cssSelector("input#Email")).sendKeys("Software Testing Material");

    }
    private static void radiobutton()
    {
        System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demoqa.com/radio-button");
        driver.manage().window().maximize();
        WebElement radioEle = driver.findElement(By.id("yesRadio"));
        boolean select = radioEle.isSelected();
        System.out.print(select);
        if (select == false) {
            radioEle.click();
        }
        WebElement radioElem = driver.findElement(By.xpath("//div/input[@id='impressiveRadio']"));
        boolean sel = radioEle.isDisplayed();
        if (sel == true) {
            radioElem.click();
        }
        WebElement radioNo = driver.findElement(By.cssSelector("input[id='noRadio']"));
        boolean selectNo = radioEle.isDisplayed();
        if (selectNo == true) {
            radioNo.click();
        }
    }
    private static void checkbox()
    {
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
        WebElement checkBox = driver.findElement(By.xpath("//*[@id='practiceForm']/div[7]/div/div/div[2]/input"));
        boolean result = checkBox.isSelected();
        System.out.println("Checking if a checkbox is selected: " + result);
        boolean result1 = checkBox.isDisplayed();
        System.out.println("Checking if a checkbox is displayed: " + result1);
        boolean result2 = checkBox.isEnabled();
        System.out.println("Checking if a checkbox is enabled: " + result2);
    }

    private static void multipledropdown() throws Exception {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/html-dropdown-elements-practice.html");
        Thread.sleep(2000);
        WebElement ideElement = driver.findElement(By.id("ide"));
        Select ideDropDown = new Select(ideElement);
        List<WebElement> ideDropDownOptions = ideDropDown.getOptions();
        for (WebElement option : ideDropDownOptions) {
            System.out.println(option.getText());
        }
        ideDropDown.selectByIndex(0);
        ideDropDown.selectByValue("ij");
        ideDropDown.selectByVisibleText("NetBeans");
        ideDropDown.deselectByVisibleText("IntelliJ IDEA");
        List<WebElement> selectedOptions = ideDropDown.getAllSelectedOptions();
        for (WebElement selectedOption : selectedOptions) {
            System.out.println("selected visible text---" + selectedOption.getText());
        }

    }

    private static void singledropdown() throws Exception {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/html-dropdown-elements-practice.html");
        Thread.sleep(2000);
        WebElement courseElement = driver.findElement(By.id("course"));
        Select courseNameDropdown = new Select(courseElement);
        List<WebElement> courseNameDropDownOptions = courseNameDropdown.getOptions();
        for (WebElement option : courseNameDropDownOptions) {
            System.out.println(option.getText());
        }
        courseNameDropdown.selectByIndex(1);
        Thread.sleep(3000);
        courseNameDropdown.selectByVisibleText("Java");
        Thread.sleep(2000);
        courseNameDropdown.selectByValue("python");
        String selectedText = courseNameDropdown.getFirstSelectedOption().getText();
        System.out.println("selected visible text" + selectedText);
    }

    private static void takescreenshot() throws IOException {
        WebDriver driver9;
        WebElement element;
        WebDriverManager.chromedriver().setup();
        driver9=new ChromeDriver();
        driver9.get("https://github.com/login");
        System.out.println("Working with Locators");
        driver9.findElement(By.cssSelector("#login_field")).sendKeys("2200030823@kluniversity.in");
        highlight9(driver9,driver9.findElement(By.cssSelector("#login_field")));
        driver9.findElement(By.cssSelector("#password")).sendKeys("Sowjanya@1980");
        highlight9(driver9,driver9.findElement(By.cssSelector("#password")));
        TakesScreenshot ts9=(TakesScreenshot)driver9;
        File file9=ts9.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file9,new File("./Screenshots/Image9.png"));
    }
    public static void highlight9(WebDriver driver, WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
    }

    private static void openurl()
    {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        System.out.println("Welcome to test world to open url");
        driver.get("https://www.amazon.in/");
        driver.quit();
    }

    private static void openbrowser()
    {
        WebDriver driver;
        System.out.println("testing on open browser");
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.get("https://www.amazon.org");

    }



    private static  void simplealert()
    {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");
        driver.findElement(By.id("alertBox")).click();
        System.out.println(driver.switchTo().alert().getText());
        driver.switchTo().alert().accept();
        System.out.println(driver.findElement(By.id("output")).getText());
    }

    private static  void confirmalert() throws Exception
    {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();

        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");

        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
        driver.findElement(By.id("confirmBox")).click();
        Thread.sleep(2000);
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
        driver.findElement(By.id("confirmBox")).click();
        Thread.sleep(2000);
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().dismiss();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());

    }


    private static  void promptalert() throws Exception
    {
        WebDriver driver;
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.hyrtutorials.com/p/alertsdemo.html");

        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
        driver.findElement(By.id("promptBox")).click();
        Thread.sleep(2000);
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().sendKeys("Sabitha");
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
        driver.findElement(By.id("promptBox")).click();
        System.out.println(driver.switchTo().alert().getText());
        Thread.sleep(2000);
        driver.switchTo().alert().dismiss();
        Thread.sleep(2000);
        System.out.println(driver.findElement(By.id("output")).getText());
        Thread.sleep(2000);
    }
}
