package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class openwebpage {
    public static void main(String[] args) {
        WebDriver driver;
        System.out.println("testing on open browser");
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.get("https://www.amazon.org");

        driver.quit();
    }
}