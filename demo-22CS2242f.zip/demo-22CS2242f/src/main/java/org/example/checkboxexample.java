package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class checkboxexample {
    public static void main(String[] args) throws InterruptedException {

        // Initiate the Webdriver
        WebDriver driver = new ChromeDriver();

        // adding implicit wait of 15 secs
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        // Opening the webpage where we will identify checkbox
        driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");

        // identify checkbox but not select
        WebElement checkBox = driver.findElement
                (By.xpath("//*[@id='practiceForm']/div[7]/div/div/div[2]/input"));

        // verify if checkbox is selected
        boolean result = checkBox.isSelected();
        System.out.println("Checking if a checkbox is selected: " + result);

        // verify if checkbox is displayed
        boolean result1 = checkBox.isDisplayed();
        System.out.println("Checking if a checkbox is displayed: " + result1);

        // verify if checkbox is enabled
        boolean result2 = checkBox.isEnabled();
        System.out.println("Checking if a checkbox is enabled: " + result2);
    }
}