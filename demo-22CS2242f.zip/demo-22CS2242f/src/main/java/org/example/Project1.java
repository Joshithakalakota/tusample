package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;


public class Project1
{
    public static void main(String[] args) throws IOException {
        WebDriver driver;
        WebElement element;
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.get("https://github.com/login");
        System.out.println("Working with Locators");
        // for static locater - ID
        driver.findElement(By.id("login_field")).sendKeys("2200030823@kluniversity.in");
        highlight(driver,driver.findElement(By.id("login_field")));
        driver.findElement(By.id("password")).sendKeys("Sowjanya@1980");
        highlight(driver,driver.findElement(By.id("password")));
        TakesScreenshot ts=(TakesScreenshot)driver;
        File file=ts.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file,new File("./Screenshots/Image1.png"));

        // for static locater - Name
       WebDriver driver1;
        WebElement element1;
        WebDriverManager.chromedriver().setup();
        driver1=new ChromeDriver();
        driver1.get("https://github.com/login");
        System.out.println("Working with Locators");
        driver1.findElement(By.name("login")).sendKeys("2200030823@kluniversity.in");
        highlight2(driver1,driver1.findElement(By.name("login")));
        driver1.findElement(By.name("password")).sendKeys("Sowjanya@1980");
        highlight2(driver1,driver1.findElement(By.name("password")));
        TakesScreenshot ts1=(TakesScreenshot)driver1;
        File file1=ts1.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file1,new File("./Screenshots/Image2.png"));


        // for Dynamic locator-XPATH
        WebDriver driver3;
        WebElement element3;
        WebDriverManager.chromedriver().setup();
        driver3=new ChromeDriver();
        driver3.get("https://github.com/login");
        System.out.println("Working with Locators");
        driver3.findElement(By.xpath("//input[@id='login_field']")).sendKeys("2200030823@kluniversity.in");
        highlight3(driver3,driver3.findElement(By.xpath("//input[@id='login_field']")));
        driver3.findElement(By.xpath("//input[@id='password']")).sendKeys("Sowjanya@1980");
        highlight3(driver3,driver3.findElement(By.xpath("//input[@id='password']")));
        TakesScreenshot ts3=(TakesScreenshot)driver3;
        File file3=ts3.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file3,new File("./Screenshots/Image3.png"));

        // for Dynamic locator-CSS Selector
    WebDriver driver4;
    WebElement element4;
    WebDriverManager.chromedriver().setup();
    driver4=new ChromeDriver();
    driver4.get("https://github.com/login");
    System.out.println("Working with Locators");
        driver4.findElement(By.cssSelector("#login_field")).sendKeys("2200030823@kluniversity.in");
    highlight4(driver4,driver4.findElement(By.cssSelector("#login_field")));
        driver4.findElement(By.cssSelector("#password")).sendKeys("Sowjanya@1980");
    highlight4(driver4,driver4.findElement(By.cssSelector("#password")));
    TakesScreenshot ts4=(TakesScreenshot)driver4;
    File file4=ts4.getScreenshotAs(OutputType.FILE);
    FileUtils.copyFile(file4,new File("./Screenshots/Image4.png"));

        WebDriver driver5;
        WebElement element5;
        WebDriverManager.chromedriver().setup();
        driver5=new ChromeDriver();
        driver5.get("https://github.com/login");
        System.out.println("Working with Locators");
        driver5.findElement(By.cssSelector("#login_field")).sendKeys("2200030823@kluniversity.in");
        highlight5(driver5,driver5.findElement(By.cssSelector("#login_field")));
        driver5.findElement(By.cssSelector("#password")).sendKeys("Sowjanya@1980");
        highlight5(driver5,driver5.findElement(By.cssSelector("#password")));
        TakesScreenshot ts5=(TakesScreenshot)driver5;
        File file5=ts5.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file5,new File("./Screenshots/Image5.png"));
}

   public static void highlight(WebDriver driver, WebElement element) {
      JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
   }
   public static void highlight2(WebDriver driver1, WebElement element1) {
        JavascriptExecutor jsExecutor1 = (JavascriptExecutor) driver1;
        jsExecutor1.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element1);
    }
public static void highlight3(WebDriver driver3, WebElement element3) {
    JavascriptExecutor jsExecutor3 = (JavascriptExecutor) driver3;
    jsExecutor3.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element3);

}
public static void highlight4(WebDriver driver4, WebElement element4) {
   JavascriptExecutor jsExecutor4= (JavascriptExecutor) driver4;
    jsExecutor4.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element4);
}
public static void highlight5(WebDriver driver5, WebElement element5) {
    JavascriptExecutor jsExecutor5= (JavascriptExecutor) driver5;
    jsExecutor5.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element5);
}
}



