package org.example;

public class welcome {
    public static void main(String[] args) {
        System.out.println("Welcome to test world");
    }
}