package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

public class inlab2Test {

    @Test
    public void test() throws IOException {

        WebDriver driver;
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.get("https://github.com/login");
        System.out.println("Working with Locators");
        WebElement emailField = driver.findElement(By.id("login_field"));
        emailField.sendKeys("2200030823@kluniversity.in");
        highlight(driver, emailField);
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Sowjanya@2004");
        highlight(driver, passwordField);
        TakesScreenshot ts = (TakesScreenshot) driver;
        File file = ts.getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(file, new File("./Screenshots/Image7.png"));
    }
    public static void highlight(WebDriver driver, WebElement element) {
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
    }
}
